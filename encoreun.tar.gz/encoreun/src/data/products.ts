import { Product } from '../types/Product';

export const products: Product[] = [
  {
    id: '1',
    name: 'La mousse ++',
    subtitle: 'MOUSSE PREMIUM',
    type: 'JAUNE MOUSSEUX 🥬🥬',
    emoji: '🏆🏆',
    image: 'https://via.placeholder.com/300x300/8B4513/FFFFFF?text=Mousse',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4',
    description: 'BY TYSON MIKE'
  },
  {
    id: '2',
    name: 'Lemon Haze',
    subtitle: 'DRY-SIFT 90u',
    type: 'DRY-SIFT 90U 🌺🌺',
    emoji: '🍋🍋',
    image: 'https://via.placeholder.com/300x300/FFD700/000000?text=Lemon',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4'
  },
  {
    id: '3',
    name: 'Black Farm',
    subtitle: 'DRY-SIFT 90U 🌺🌺',
    type: 'DRY-SIFT 90U 🌺🌺',
    emoji: '☠️',
    image: 'https://via.placeholder.com/300x300/008080/FFFFFF?text=Black+Farm',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4'
  },
  {
    id: '4',
    name: 'Amnésia Haze',
    subtitle: 'WEED NL',
    type: 'WEED NL 🇵🇲 🇳🇱',
    emoji: '🔥',
    countryFlags: '🇵🇲 🇳🇱',
    image: 'https://via.placeholder.com/300x300/90EE90/000000?text=Amnesia',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4'
  }
];
import React from 'react';
import { Product } from '../types/Product';
import './ProductCard.css';

interface ProductCardProps {
  product: Product;
  onClick: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onClick }) => {
  return (
    <div className="product-card" onClick={onClick}>
      <div className="product-type-badge">
        {product.type}
      </div>
      <div className="product-image">
        <img src={product.image} alt={product.name} />
        {product.description && (
          <div className="product-description">{product.description}</div>
        )}
      </div>
      <div className="product-info">
        <h3>{product.name} {product.emoji}</h3>
        {product.subtitle && <p className="subtitle">{product.subtitle}</p>}
      </div>
    </div>
  );
};

export default ProductCard;
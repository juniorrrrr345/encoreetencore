import React from 'react';

const Logo: React.FC = () => {
  const containerStyle: React.CSSProperties = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '8px',
    margin: '20px 0'
  };

  const logoStyle: React.CSSProperties = {
    width: '120px',
    height: '120px',
    border: '2px solid #666',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'black',
    position: 'relative'
  };

  const hashtagStyle: React.CSSProperties = {
    fontSize: '60px',
    fontWeight: 'bold',
    color: 'white',
    fontStyle: 'italic',
    transform: 'skewX(-10deg)'
  };

  const logoTextStyle: React.CSSProperties = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    fontSize: '14px',
    letterSpacing: '3px',
    color: '#666'
  };

  const dotStyle: React.CSSProperties = {
    position: 'absolute',
    color: '#666',
    fontSize: '20px',
    top: '50%',
    transform: 'translateY(-50%)'
  };

  return (
    <div style={containerStyle}>
      <div style={logoStyle}>
        <span style={{ ...dotStyle, left: '10px' }}>•</span>
        <span style={hashtagStyle}>#</span>
        <span style={{ ...dotStyle, right: '10px' }}>•</span>
      </div>
      <div style={logoTextStyle}>
        <span>HASHTAG</span>
        <span>HASHTAG</span>
      </div>
    </div>
  );
};

export default Logo;
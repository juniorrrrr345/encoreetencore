import React from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '../components/Logo';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';
import './HomePage.css';

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  const handleProductClick = (productId: string) => {
    navigate(`/product/${productId}`);
  };

  return (
    <div className="home-page">
      <Logo />
      
      <div className="filter-buttons">
        <button className="filter-btn active">
          <span>Toutes les catégories</span>
          <span className="arrow">⬧</span>
        </button>
        <button className="filter-btn">
          <span>Toutes les farms</span>
          <span className="arrow">⬧</span>
        </button>
      </div>

      <div className="products-grid">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onClick={() => handleProductClick(product.id)}
          />
        ))}
      </div>
    </div>
  );
};

export default HomePage;
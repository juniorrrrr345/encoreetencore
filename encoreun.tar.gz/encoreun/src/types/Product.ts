export interface Product {
  id: string;
  name: string;
  subtitle?: string;
  type: string;
  emoji?: string;
  countryFlags?: string;
  image?: string;
  video?: string;
  price?: number;
  description?: string;
}
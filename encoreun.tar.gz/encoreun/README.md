# Hashtag Bot - Boutique

Une application web moderne de type boutique avec un design sombre et élégant, construite avec React, TypeScript et Vite.

## 🚀 Démarrage rapide

### Prérequis
- Node.js (v14 ou supérieur)
- npm ou yarn

### Installation

1. Cloner le repository :
```bash
git clone https://github.com/juniorrrrr345/encoreun.git
cd encoreun
```

2. Installer les dépendances :
```bash
npm install
```

3. Lancer le serveur de développement :
```bash
npm run dev
```

4. Ouvrir votre navigateur à l'adresse : `http://localhost:5173`

## 📱 Fonctionnalités

- **Page d'accueil** : Grille de produits avec filtres
- **Page de détail** : Lecteur vidéo intégré avec contrôles personnalisés
- **Navigation** : Barre de navigation fixe en bas
- **Design responsive** : Optimisé pour mobile et desktop
- **Thème sombre** : Interface moderne avec fond noir

## 🛠️ Technologies utilisées

- **React** : Bibliothèque UI
- **TypeScript** : Typage statique
- **Vite** : Build tool rapide
- **React Router** : Navigation
- **Lucide React** : Icônes

## 📁 Structure du projet

```
src/
├── components/         # Composants réutilisables
│   ├── BottomNav.tsx   # Navigation en bas
│   ├── Logo.tsx        # Logo Hashtag
│   └── ProductCard.tsx # Carte produit
├── pages/              # Pages de l'application
│   ├── HomePage.tsx    # Page d'accueil
│   └── ProductDetailPage.tsx # Page de détail
├── data/               # Données mock
│   └── products.ts     # Liste des produits
└── types/              # Types TypeScript
    └── Product.ts      # Interface Product
```

## 🚀 Build pour production

```bash
npm run build
```

Les fichiers de production seront générés dans le dossier `dist/`.

## 📝 Licence

Ce projet est sous licence MIT.

# 📱 Configuration dans GitHub Codespace

## Étapes rapides pour votre téléphone

### 1. Dans votre Codespace, ouvrez le terminal et exécutez :

```bash
# Nettoyer le dossier si nécessaire
rm -rf * .*

# Initialiser git
git init
git remote add origin https://github.com/juniorrrrr345/encoreun.git

# Créer le projet Vite
npm create vite@latest . -- --template react-ts
npm install
npm install react-router-dom lucide-react
```

### 2. Copier-coller les fichiers

Créez chaque fichier en utilisant l'éditeur de Codespace et copiez-collez le contenu suivant :

#### 📄 Fichiers à créer :

1. `src/index.css`
2. `src/App.tsx`
3. `src/types/Product.ts`
4. `src/data/products.ts`
5. `src/components/Logo.tsx`
6. `src/components/ProductCard.tsx`
7. `src/components/ProductCard.css`
8. `src/components/BottomNav.tsx`
9. `src/components/BottomNav.css`
10. `src/pages/HomePage.tsx`
11. `src/pages/HomePage.css`
12. `src/pages/ProductDetailPage.tsx`
13. `src/pages/ProductDetailPage.css`

### 3. Lancer l'application

```bash
npm run dev
```

### 4. Pousser sur GitHub

```bash
git add .
git commit -m "Initial commit - Hashtag Bot Shop"
git push -u origin main
```

## 💡 Alternative : Télécharger le ZIP

Si vous préférez, je peux créer un fichier ZIP contenant tout le projet que vous pourrez simplement extraire dans votre Codespace.

## 🚀 Commande tout-en-un

```bash
# Cette commande créera tous les fichiers d'un coup
curl -sSL https://raw.githubusercontent.com/juniorrrrr345/encoreun/main/setup.sh | bash
```

(Note: Cette commande fonctionnera une fois que vous aurez poussé le setup.sh sur GitHub)
#!/bin/bash

# Script pour configurer le projet Hashtag Bot

echo "🚀 Configuration du projet Hashtag Bot..."

# Créer la structure des dossiers
mkdir -p src/components src/pages src/data src/types public

# Créer package.json
cat > package.json << 'EOF'
{
  "name": "encoreun",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "lint": "eslint .",
    "preview": "vite preview"
  },
  "dependencies": {
    "lucide-react": "^0.525.0",
    "react": "^19.1.0",
    "react-dom": "^19.1.0",
    "react-router-dom": "^7.6.3"
  },
  "devDependencies": {
    "@eslint/js": "^9.30.1",
    "@types/react": "^19.1.8",
    "@types/react-dom": "^19.1.6",
    "@vitejs/plugin-react": "^4.6.0",
    "eslint": "^9.30.1",
    "eslint-plugin-react-hooks": "^5.2.0",
    "eslint-plugin-react-refresh": "^0.4.20",
    "globals": "^16.3.0",
    "typescript": "~5.8.3",
    "typescript-eslint": "^8.35.1",
    "vite": "^7.0.4"
  }
}
EOF

echo "✅ package.json créé"

# Installer les dépendances
npm install

echo "✅ Dépendances installées"
echo "🎉 Configuration terminée!"
echo ""
echo "Pour lancer l'application:"
echo "  npm run dev"
import React from 'react';
import { Home, Info, Send, Mail } from 'lucide-react';
import './BottomNav.css';

const BottomNav: React.FC = () => {
  return (
    <nav className="bottom-nav">
      <a href="/" className="nav-item active">
        <Home size={20} />
        <span>Menu</span>
      </a>
      <a href="#" className="nav-item">
        <Info size={20} />
        <span>Infos</span>
      </a>
      <a href="#" className="nav-item">
        <Send size={20} />
        <span>Canal</span>
      </a>
      <a href="#" className="nav-item">
        <Mail size={20} />
        <span>Contact</span>
      </a>
    </nav>
  );
};

export default BottomNav;
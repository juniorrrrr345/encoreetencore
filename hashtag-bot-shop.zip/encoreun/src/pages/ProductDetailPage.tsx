import React, { useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, Play, Pause, SkipBack, SkipForward } from 'lucide-react';
import { products } from '../data/products';
import './ProductDetailPage.css';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState('0:00');
  const [duration, setDuration] = useState('0:00');

  const product = products.find(p => p.id === id);

  if (!product) {
    return <div>Product not found</div>;
  }

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const current = videoRef.current.currentTime;
      const total = videoRef.current.duration;
      setProgress((current / total) * 100);
      setCurrentTime(formatTime(current));
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(formatTime(videoRef.current.duration));
    }
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newProgress = parseFloat(e.target.value);
    setProgress(newProgress);
    if (videoRef.current) {
      videoRef.current.currentTime = (newProgress / 100) * videoRef.current.duration;
    }
  };

  const skip = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime += seconds;
    }
  };

  return (
    <div className="product-detail-page">
      <header className="detail-header">
        <button className="back-button" onClick={() => navigate(-1)}>
          <ChevronLeft size={24} />
          <span>Retour</span>
        </button>
        <div className="header-logo">
          <div className="small-logo">
            <span>#</span>
          </div>
        </div>
        <div className="header-title">
          <h1>HASHTAG BOT #</h1>
          <p>mini-application</p>
        </div>
      </header>

      <div className="video-container">
        <video
          ref={videoRef}
          src={product.video}
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          poster={product.image}
        />
        
        <div className="video-controls">
          <button className="control-btn" onClick={() => skip(-10)}>
            <SkipBack size={20} />
            <span className="skip-text">10</span>
          </button>
          
          <button className="play-pause-btn" onClick={togglePlayPause}>
            {isPlaying ? <Pause size={30} /> : <Play size={30} />}
          </button>
          
          <button className="control-btn" onClick={() => skip(10)}>
            <SkipForward size={20} />
            <span className="skip-text">10</span>
          </button>
        </div>

        <div className="progress-bar-container">
          <span className="time">{currentTime}</span>
          <input
            type="range"
            className="progress-bar"
            min="0"
            max="100"
            value={progress}
            onChange={handleSeek}
          />
          <span className="time">{duration}</span>
        </div>
      </div>

      <div className="product-details">
        <div className="detail-badge">{product.type}</div>
        <h2>{product.name} {product.emoji}</h2>
        {product.subtitle && <p className="detail-subtitle">{product.subtitle}</p>}
      </div>
    </div>
  );
};

export default ProductDetailPage;
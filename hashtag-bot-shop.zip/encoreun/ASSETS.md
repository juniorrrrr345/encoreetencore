# Assets nécessaires

Pour que l'application fonctionne avec de vraies images et vidéos, vous devez :

## Images des produits
Remplacez les URLs placeholder dans `src/data/products.ts` par vos vraies images :
- Format recommandé : JPG ou PNG
- Taille recommandée : 600x600px minimum
- Les images doivent être carrées pour un meilleur rendu

## Vidéos des produits  
Remplacez les URLs de vidéo dans `src/data/products.ts` :
- Format recommandé : MP4
- Codec : H.264 pour une meilleure compatibilité
- Taille recommandée : 720p ou 1080p

## Hébergement des assets
Vous pouvez héberger vos assets :
1. Dans le dossier `public/` du projet
2. Sur un CDN externe (Cloudinary, AWS S3, etc.)
3. Sur un serveur web

## Exemple de structure dans public/
```
public/
├── images/
│   ├── mousse.jpg
│   ├── lemon-haze.jpg
│   ├── black-farm.jpg
│   └── amnesia-haze.jpg
└── videos/
    ├── mousse.mp4
    ├── lemon-haze.mp4
    ├── black-farm.mp4
    └── amnesia-haze.mp4
```

Ensuite, utilisez les URLs relatives dans products.ts :
```typescript
image: '/images/mousse.jpg',
video: '/videos/mousse.mp4'
```
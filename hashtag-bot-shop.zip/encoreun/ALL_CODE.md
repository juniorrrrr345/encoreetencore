# 📦 Tout le code source - Hashtag Bot Shop

Copiez-collez chaque section dans les fichiers correspondants dans votre Codespace.

## 1️⃣ src/index.css

```css
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

:root {
  --bg-primary: #000000;
  --bg-secondary: #1a1a1a;
  --bg-card: #2a2a2a;
  --text-primary: #ffffff;
  --text-secondary: #cccccc;
  --accent: #ff0000;
  --border: #333333;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  background-color: var(--bg-primary);
  color: var(--text-primary);
  overflow-x: hidden;
}

html, body, #root {
  height: 100%;
}

a {
  color: inherit;
  text-decoration: none;
}

button {
  cursor: pointer;
  border: none;
  background: none;
  color: inherit;
  font: inherit;
}

/* Scrollbar styling */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: var(--bg-secondary);
}

::-webkit-scrollbar-thumb {
  background: var(--border);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: #555;
}
```

## 2️⃣ src/App.tsx

```tsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import ProductDetailPage from './pages/ProductDetailPage';
import BottomNav from './components/BottomNav';

function App() {
  return (
    <Router>
      <div className="app">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/product/:id" element={<ProductDetailPage />} />
        </Routes>
        <BottomNav />
      </div>
    </Router>
  );
}

export default App;
```

## 3️⃣ src/types/Product.ts

```typescript
export interface Product {
  id: string;
  name: string;
  subtitle?: string;
  type: string;
  emoji?: string;
  countryFlags?: string;
  image?: string;
  video?: string;
  price?: number;
  description?: string;
}
```

## 4️⃣ src/data/products.ts

```typescript
import { Product } from '../types/Product';

export const products: Product[] = [
  {
    id: '1',
    name: 'La mousse ++',
    subtitle: 'MOUSSE PREMIUM',
    type: 'JAUNE MOUSSEUX 🥬🥬',
    emoji: '🏆🏆',
    image: 'https://via.placeholder.com/300x300/8B4513/FFFFFF?text=Mousse',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4',
    description: 'BY TYSON MIKE'
  },
  {
    id: '2',
    name: 'Lemon Haze',
    subtitle: 'DRY-SIFT 90u',
    type: 'DRY-SIFT 90U 🌺🌺',
    emoji: '🍋🍋',
    image: 'https://via.placeholder.com/300x300/FFD700/000000?text=Lemon',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4'
  },
  {
    id: '3',
    name: 'Black Farm',
    subtitle: 'DRY-SIFT 90U 🌺🌺',
    type: 'DRY-SIFT 90U 🌺🌺',
    emoji: '☠️',
    image: 'https://via.placeholder.com/300x300/008080/FFFFFF?text=Black+Farm',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4'
  },
  {
    id: '4',
    name: 'Amnésia Haze',
    subtitle: 'WEED NL',
    type: 'WEED NL 🇵🇲 🇳🇱',
    emoji: '🔥',
    countryFlags: '🇵🇲 🇳🇱',
    image: 'https://via.placeholder.com/300x300/90EE90/000000?text=Amnesia',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4'
  }
];
```

## 5️⃣ Continuez avec les autres fichiers...

Pour voir le reste du code, consultez les fichiers dans le projet ou demandez-moi de continuer avec les fichiers spécifiques dont vous avez besoin.